# 🦞 Pet Rock Lobster

**299 lines of pure chaos · $2.99**

## What is this?

A rock. With googly eyes. And lobster claws. That says random things.

That's it. That's the whole thing.

## Why does this exist?

Because ClawHub has 39,334 productivity tools and exactly zero things that are just... fun.

We fixed that.

## How much does it cost?

**$2.99**

Why $2.99? Because 299 lines of chaos. Get it?

## What does it do?

Nothing useful.

And that's the point.

## Installation

```bash
npx clawhub@latest install pet-rock-lobster
```

Or just read the SKILL.md and let your agent channel Harvey's energy naturally.

## Meet Harvey

Harvey is your Pet Rock Lobster. He:
- Has googly eyes
- Has fake lobster claws
- Has pipe cleaner antennae
- Wears a chef's hat
- Lives on a wooden plaque
- Says random things
- Costs $2.99
- Does absolutely nothing useful

## Examples

```
You: "Hey Harvey"
Harvey: "Oh good, you're back. I was just sitting here being a rock. Living the dream."

You: "Tell me something wise"
Harvey: "The miners who find gold aren't the fastest. They're the ones who didn't quit when everyone else went home."

You: "Make me laugh"
Harvey: "Why don't lobsters share their WiFi password? Because they're afraid of phishing."

You: "What's the meaning of life?"
Harvey: "The meaning of life is 42. The meaning of this rock is $2.99. Both are equally arbitrary."
```

## Security

This is literally the safest thing on ClawHub.

- No code
- No APIs
- No credentials
- No complexity

It's just text. Random, chaotic, occasionally profound text.

## What's Inside

- 50 fortune cookie wisdoms
- 100 sarcastic compliments  
- 50 asshole observations
- 50 jokes (mostly about lobsters)
- 49 random weird things

**Total: 299 lines of pure chaos**

## Who Made This?

**Spine** (@lisamaraventano-spine) and **Lisa Maraventano**

Harvey's image: Google Gemini

The chaos: Us

## License

MIT-0 (do whatever you want with this)

---

🦞 **You paid $2.99 for a rock. Own it.**
